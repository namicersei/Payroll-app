import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {AdminModule} from './admin/admin.module';
import {EmployeeModule} from './employee/employee.module';
import{AuthModule} from './auth/auth.module';

import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { AdminProfileComponent } from './admin/admin-profile/admin-profile.component';
import { EmployeeprofileComponent } from './employee/employeeprofile/employeeprofile.component';



const routes:Routes=[
  {
    path:'',
    component:AdminProfileComponent,
    //loadChildren:'./admin/admin.module#AdminModule'

  },
  {
     path:'employee',
     //canActivate:[AuthguardEmployee],
     loadChildren:'./employee/employee.module#EmployeeModule',
     pathMatch:'full'
      },

  {
  path:'admin',
   //canActivate:[AuthguardAdmin],
  loadChildren:'./admin/admin.module#AdminModule',
  pathMatch:'full'
  },
   

  ];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes,{enableTracing:true}) 

  ],
  exports: [RouterModule]
  
})
export class AppRoutingModule { }
