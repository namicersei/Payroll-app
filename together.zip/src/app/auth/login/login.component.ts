import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { first } from 'rxjs/operators';
import { ServicesService } from '../../services.service';
import { UserData } from '../../../assets/userdata';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as jwt_decode from "jwt-decode";


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[ServicesService]
})
export class LoginComponent implements OnInit {

  private inputname="";
  private  pass="";
  returnUrl:string="";


  constructor(private userService:ServicesService, private router:Router) { }


  ngOnInit() {
 
  }

//login part
authenticate(){
  //implement validation
  this.userService.login(this.inputname,this.pass).subscribe(
    (data:UserData) => {
        
       const details:any=jwt_decode(data.token);
       console.log(data);
       console.log(details);

   
        if(data)
        {
          localStorage.setItem('currentUser',JSON.stringify({loginEmail:this.inputname,token:data.token}));

        }
       if(details.isAdmin)
       {
        this.router.navigate(['/admin']);
       }
       else{
         this.router.navigate(['/employee']);
       }

    } 
  )
}
}
