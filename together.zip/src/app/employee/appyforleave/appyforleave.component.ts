import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appyforleave',
  templateUrl: './appyforleave.component.html',
  styleUrls: ['./appyforleave.component.css']
})
export class AppyforleaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
