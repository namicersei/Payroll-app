import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approveleave',
  templateUrl: './approveleave.component.html',
  styleUrls: ['./approveleave.component.css']
})
export class ApproveleaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
