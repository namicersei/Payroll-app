import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payemployee',
  templateUrl: './payemployee.component.html',
  styleUrls: ['./payemployee.component.css']
})
export class PayemployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
