import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpayment',
  templateUrl: './editpayment.component.html',
  styleUrls: ['./editpayment.component.css']
})
export class EditpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
