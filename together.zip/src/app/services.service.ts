import { Injectable, NgModule } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { map } from 'rxjs/operators';
import {UserData} from '../assets/userdata'; //structure of the data



@Injectable()


export class ServicesService {

  private url='http://139.59.14.81:3000/api/v1/login';

  constructor(private http:HttpClient) { }


  login(username:string,password:string):Observable<UserData>{
    return this.http.post<UserData>(this.url,{loginEmail:username,loginPassword:password});

    }
  }
 

